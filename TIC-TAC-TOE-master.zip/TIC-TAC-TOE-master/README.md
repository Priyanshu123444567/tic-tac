Welcome⚡
--------|
![](https://media.tenor.com/iVCiM9W7cvYAAAAd/welcome.gif)

### The TIC TAC TOE game, created using JavaScript, and The HTML5 canvas.

### TIC TAC TOE GAME WITH REAL SCORE

<a href="https://u7p4l-in.github.io/TIC-TAC-TOE/"><strong>➥ Live Demo</strong></a>




